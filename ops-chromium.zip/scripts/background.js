// Ethan Kuoch

let nfl = true;
let nba = true;
let mlb = true;
let nhl = true;
let military_format = false;

chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.set({ nfl, nba, mlb, nhl, military_format });
  console.log("Defaults set")
});
